<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Staff_management extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Staff_management.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Staff_management.php */