<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Quotation_setting extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Quotation_setting.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Quotation_setting.php */