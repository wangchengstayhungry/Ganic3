<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Delivery_order extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Delivery_order.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Delivery_order.php */