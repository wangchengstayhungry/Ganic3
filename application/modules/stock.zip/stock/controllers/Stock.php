<?php
		defined('BASEPATH') OR exit('No direct script access allowed');

		class Stock extends MY_Controller {

			public function __construct()
		    {
		        parent::__construct();
		        $this->load->model('stock/stock_model','stock');
		    }	
			
		    public function opening_balance()
	 		{
	 			is_logged_in('admin');
	 			has_permission();
	 			$this->body_vars['product_options']=$this->custom->createDropdownSelect("billing_master",array('billing_id','stock_code','billing_description'),"Product",array(" : "," "));
				$this->body_vars['save_url']=base_url('stock/create_stocktable');
	 			$this->body_file="stock/opening_balance.php";

	 		}	

	 		public function create_stocktable($action="new")
	 		{

	 			is_logged_in('admin');
				has_permission(); 
				$post=$this->input->post();
				
				if (isset($post)) {

					$open_data = $post;
					// print_r($post);exit;
					if($action=="new"){
						$insert_data = array();
						if (isset($insert_data)) {
							unset($insert_data);
						}
						$count = count($post['data']['transaction_date']);
						foreach ($post['data']['transaction_date'] as $transaction_date){
						   print_r($transaction_date);
						   $insert_data['open_tran_date'][] = $transaction_date;
						}
						foreach ($post['data']['doc_reference'] as $doc_reference) {
							$insert_data['open_doc_ref'][] = $doc_reference;
						}
						foreach ($post['data']['remarks'] as $remarks) {
							$insert_data['open_remarks'][] = $remarks;
						}
						foreach ($post['data']['amount'] as $amount) {
							$insert_data['open_amount'][] = $amount;
						}
						foreach($post['data']['sign'] as $sign) {
							$insert_data['open_sign'][] = $sign;
						}
						
						for ($i=0; $i < $count ; $i++) { 
							$data['open_tran_date'] = $insert_data['open_tran_date'][$i];
							$data['open_doc_ref'] = $insert_data['open_doc_ref'][$i];
							$data['open_remarks'] = $insert_data['open_remarks'][$i];
							$data['open_amount'] = $insert_data['open_amount'][$i];
							$data['open_sign'] = $insert_data['open_sign'][$i];
							$data['customer_id'] = $post['customer_id'];
							$open_id[]=$this->custom->insertRow("open_table",$data);
						}
					}

					if($action=="edit"){
						
						$where=array('open_id' => $open_data['data']['open_id'][0]);

						$data['open_tran_date'] = $open_data['data']['transaction_date'][0];
						$data['open_doc_ref'] = $open_data['data']['doc_reference'][0];
						$data['open_remarks'] = $open_data['data']['remarks'][0];
						$data['open_amount'] = $open_data['data']['amount'][0];
						$data['open_sign'] = $open_data['data']['sign'][0];
						$data['customer_id'] = $post['customer_id'];

						unset($open_data['open_id']);

						$this->db->trans_start();
						$res[]=$this->custom->updateRow("open_table",$data,$where);
						
						if ($this->db->trans_status() === FALSE || in_array("error", $res))
						{
							set_flash_message("message","danger","Something Went Wrong");	
						    $this->db->trans_rollback();
						}
						else
						{
							set_flash_message("message","success","receipt Updated Successfully");
						    $this->db->trans_commit();
						}
					}
					redirect('account/openlist/confirm');
				}
	 		}
		}

?>