<section class="content-header">
  <h1>
    Opening Balance
    <!-- <small>Preview of UI elements</small> -->
  </h1>
  <?php 
    $list = array('active'=>'Account');
    echo breadcrumb($list); 
  ?>
</section>
<br>
<section class="content">
  <?php echo get_flash_message('message'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="box box-info">
        <div class="box-header with-border">
          <div class="tooltip">Hover over me
  <span class="tooltiptext">Tooltip text</span>
</div>
          <h3 class="box-title">Stock</h3>
        </div>
      </div>
    </div>
  </div>
  <form autocomplete="off" id="form_" class="form-horizontal validate" method="post" action="<?php echo $save_url; ?>"> 
    <div class="row">
      <div class="col-md-12">
        <div class="box box-danger">
          <div class="row">
            <div class="col-md-12">
              <div class="box-body">
                <section class="receipt">
                  
                  <br>
                  <hr>
                  <div class="table-responsive">
                    <table class="table" id="open_table">
                      <thead>
                        <tr>
                          <th>Stock code</th>
                          <th>Stock Description</th>
                          <th>UOM</th>
                          <th>Quantity</th>
                          <th>Sign</th>
                          <th>Transaction Type</th>
                          <th>ACTION</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <select name="product_id" id="product_id" title="Select Product" class="form-control select2" >
                              <?php echo $product_options; ?>
                            </select>
                            <!-- <input type="date" class="stock_code form-control" name="data[stock_code][0]"> -->
                          </td>
                          <td>
                            <input type="text" class="stock_description form-control" name="data[stock_description][0]">
                          </td>
                          <td>
                            <input type="text" class="UOM form-control" name="data[uom][0]">
                          </td>
                          <td>
                            <input type="text" class="quantity form-control" name="data[quantity][0]">
                          </td>
                          <td>
                            <input type="text" class="sign form-control" name="data[sign][0]" value="+">
                          </td>
                          <td>
                            <input type="text" class="tran_type form-control" name="data[tran_type][0]">
                          </td>
                          <td>
                            <button class="form-control btn-warning" id="del_btn" onclick="delete_row(this)">Delete</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>


                  </div>
                  <div class="col-md-6 col-md-offset-6 col-xs-12">
                      <div id="another_entry" class="pull-right">
                        Input Another Entry?

                        <button type="button" class="btn btn-primary" id="input_another_entry">Yes</button>
                      
                        <button type="button" class="btn btn-primary " onclick="$('#another_entry').hide();$('#submitbtn').removeClass('hidden');">No</button> 
                      </div>
                      
                  </div>
                  
                  <br>
                
                  <!-- <legend></legend> -->
                  <!-- Table row -->
                  
                  <!-- /.row -->
                  <!-- <hr> -->
                  <div class="row no-print">
                    <div class="col-xs-12">
                      <button type="submit" class="btn btn-success pull-right hidden" id="submitbtn"><i class="fa fa-credit-card"></i> Submit
                      </button>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
</section>
<!-- <script type="text/javascript" src="<?php echo JS_PATH ?>receipt.js"></script> -->
<script type="text/javascript">
$(function() {
  //=========================customer details ====================================================

  $cansend = false;
  
  
  
    $('form#form_').submit(function(){
     var form = $(this);
         if ($cansend == true)
            {
                $cansend = false;
                return true;
            }
            $('#quot_status').html('');
            $.confirm({
                title:"<i class='fa fa-info'></i> Opening Balance Confirmation",
                text: "Confirm?",
                cancelButton: "No",
                confirm: function(button) {
                  $('#quot_status').html('');
                    $('#quot_status').html('<input type="hidden" name="invoice_status" value="C">');
                    $cansend = true;
                    
                  //  console.log($("#lump_sum_discount").val);
                    form.submit();
                },
                cancel: function(button) {
                 
                    $cansend = true;
                    form.submit();
                }
            });
            return false;
  })


  
 
  $("#input_another_entry").click(function(evernt) {
    var numrows = $("form#form_").find("input[name^='data[stock_code]']").length;
    console.log(numrows);
    var append_str_entry = '<tr>' 
                          +'<td>'
                          + '<input type="date" class="form-control" name="data[stock_code]['
                          + numrows
                          + ']">'
                          + '</td>'
                          + '<td>'
                          + '<input type="text" class="form-control" name="data[stock_description]['
                          + numrows
                          + ']">'
                          + '</td>'
                          + '<td>'
                          +  '<input type="text" class="form-control" name="data[uom]['
                          + numrows
                          + ']">'
                          + '</td>'
                          + '<td>'
                          +  '<input type="text" class="form-control" name="data[quantity]['
                          + numrows
                          + ']">'
                          + '</td>'
                          + '<td>'
                          + '<input type="text" class="form-control" name="data[sign]['
                          + numrows
                          + ']" value="+">'
                          + '</td>'
                          + '<td>'
                          + '<input type="text" class="form-control" name="data[tran_type]['
                          + numrows
                          + ']">'
                          + '</td>'
                          + '<td>'
                          + '<button class="form-control btn-warning" onclick="delete_row(this)">Delete</button>'
                          + '</td>'
                          + '</tr>';

    $("#open_table tbody").append(append_str_entry);
    //console.log(index_add);
  });
  
    //===============================================invoice reference ===================================
  $("#invoice_reference_id").change(function(event) {
      var invoice_id = [];

      $.each($("#invoice_reference_id option:selected"), function(){            
          invoice_id.push($(this).val());
      });
      
      if(invoice_id!=""){
          $.post('<?php echo base_url('common/Ajax/receiptlist_ajax/get_receipt_data') ?>', {  invoice_id: invoice_id}, function(data, textStatus, xhr) {
            obj = $.parseJSON(data);
            console.log(typeof obj.invoic_name);
            console.log(obj);
            $("#invoice_reference").html(obj.invoic_name.join(", "));
            $("#amountinwords").html(' '+obj.total_in_words);
            $("#rec_amount").val(obj.total);

            $("#rec_invoice").val(obj.invoic_name);

          });
      }
  
  });
});

function delete_row(data) {
    
    $(data).parents("tr").remove();
}

</script>