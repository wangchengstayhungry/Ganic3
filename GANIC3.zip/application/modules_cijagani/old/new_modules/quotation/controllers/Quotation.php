<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Quotation extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Quotation.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Quotation.php */