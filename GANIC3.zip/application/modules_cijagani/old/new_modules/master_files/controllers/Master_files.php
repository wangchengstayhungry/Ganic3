<?php
		defined('BASEPATH') OR exit('No direct script access allowed');
		
		class Master_files extends MY_Controller {
		
			public function index()
			{
				
			}
		
		}
		
		/*End of file Master_files.php */
		/* Location: ./application/modules/new_modules/company_profile/controllers/Master_files.php */